
# Operation Type Enum

Possible operators are sum, subtract, multiply, divide

## Enumeration

`OperationTypeEnum`

## Fields

| Name |
|  --- |
| `sUM` |
| `sUBTRACT` |
| `mULTIPLY` |
| `dIVIDE` |

## Example

```
SUM
```

