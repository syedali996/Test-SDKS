
# Operation Type Enum

Possible operators are sum, subtract, multiply, divide

## Enumeration

`OperationTypeEnum`

## Fields

| Name |
|  --- |
| `SUM` |
| `SUBTRACT` |
| `MULTIPLY` |
| `DIVIDE` |

## Example

```
SUM
```

